<?php

namespace App\Http\Livewire;

use Livewire\Component;

class HowitWorksPageComponent extends Component
{
    public function render()
    {
        return view('livewire.howit-works-page-component')->layout('layouts.base');
    }
}
