<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class AdminemailSubsComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.adminemail-subs-component');
    }
}
