<?php

namespace App\Http\Livewire;

use Livewire\Component;

class TermsOfServicesComponent extends Component
{
    public function render()
    {
        return view('livewire.terms-of-services-component')->layout('layouts.base');
    }
}
